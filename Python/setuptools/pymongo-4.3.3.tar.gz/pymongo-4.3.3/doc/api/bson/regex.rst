:mod:`regex` -- Tools for representing MongoDB regular expressions
==================================================================
.. versionadded:: 2.7

.. automodule:: bson.regex
   :synopsis: Tools for representing MongoDB regular expressions
   :members:
