:mod:`dbref` -- Tools for manipulating DBRefs (references to documents stored in MongoDB)
=========================================================================================

.. automodule:: bson.dbref
   :synopsis: Tools for manipulating DBRefs (references to documents stored in MongoDB)
   :members:
