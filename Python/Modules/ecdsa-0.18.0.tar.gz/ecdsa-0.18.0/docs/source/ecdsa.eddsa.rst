ecdsa.eddsa module
==================

.. automodule:: ecdsa.eddsa
   :members:
   :undoc-members:
   :show-inheritance:
