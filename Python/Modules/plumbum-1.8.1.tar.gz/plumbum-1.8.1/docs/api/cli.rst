.. _api-cli:

Package plumbum.cli
===================
.. automodule:: plumbum.cli.application
   :members:

.. automodule:: plumbum.cli.switches
   :members:

.. automodule:: plumbum.cli.terminal
   :members:

.. automodule:: plumbum.cli.termsize
   :members:

.. automodule:: plumbum.cli.progress
   :members:
