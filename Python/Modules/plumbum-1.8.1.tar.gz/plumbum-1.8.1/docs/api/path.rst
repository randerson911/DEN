.. _api-path:

Package plumbum.path
====================
.. automodule:: plumbum.path.base
   :members:
   :special-members:

.. automodule:: plumbum.path.local
   :members:
   :special-members:

.. automodule:: plumbum.path.remote
   :members:
   :special-members:

Utils
-----
.. automodule:: plumbum.path.utils
   :members:
   :special-members:
