Package plumbum.colors
======================

.. automodule:: plumbum.colors
   :members:
   :special-members:

plumbum.colorlib
----------------

.. automodule:: plumbum.colorlib
   :members:
   :special-members:

plumbum.colorlib.styles
-----------------------

.. automodule:: plumbum.colorlib.styles
   :members:
   :special-members:

plumbum.colorlib.factories
--------------------------

.. automodule:: plumbum.colorlib.factories
   :members:
   :special-members:

plumbum.colorlib.names
----------------------

.. automodule:: plumbum.colorlib.names
   :members:
   :special-members:
