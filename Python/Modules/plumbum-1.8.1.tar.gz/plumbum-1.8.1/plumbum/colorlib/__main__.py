"""
This is provided as a quick way to recover your terminal. Simply run
``python3 -m plumbum.colorlib``
to recover terminal color.
"""


from . import main

main()
