Release notes have moved to `elastic.co/guide <https://www.elastic.co/guide/en/elasticsearch/client/python-api/current/release-notes.html>`_.
